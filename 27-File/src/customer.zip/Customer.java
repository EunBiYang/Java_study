package customer;

public interface Customer {
   public void input();            	// 입력
   public void print();            	// 출력
   public void printTitle();        // 제목 출력
   public void searchCustomerNum(); // 고객번호 검색
   public void searchName();        // 이름 검색
   public void searchContactNum();  // 전화번호 검색
   public void descSortName();      // 이름 내림차순 정렬
   public void ascSortCustomerNum();// 고객번호 오름차순 정렬
}
