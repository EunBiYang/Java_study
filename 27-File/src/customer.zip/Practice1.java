package customer;

import java.util.Scanner;

public class Practice1 {
   public static void main(String[] args) {
   
      Scanner sc = new Scanner(System.in);
      Customer customer = new CustomerImpl(); 
      int num;
   
      while(true) {
         do {
            System.out.println("1. 입력");
            System.out.println("2. 출력");
            System.out.println("3. 고객번호검색");
            System.out.println("4. 이름검색");
            System.out.println("5. 전화번호검색");
            System.out.println("6. 이름 내림차순 정렬");
            System.out.println("7. 고객번호 오름차순 정렬");
            System.out.println("8. 종료");
            System.out.println("------------------");
            System.out.print("번호 : ");
            num = sc.nextInt();
         } while(num<1 || num>8);
         System.out.println();

         switch(num) {
         case 1: // 입력
            customer.input();
            break;
         case 2: // 출력
            customer.print();
            break;
         case 3: // 고객번호검색
            customer.searchCustomerNum();
            break;
         case 4: // 이름검색
            customer.searchName();
            break;
         case 5: // 전화번호검색
            customer.searchContactNum();
            break;
         case 6: // 이름 내림차순 정렬
            customer.descSortName();
            break;
         case 7: // 고객번호 오름차순 정렬
            customer.ascSortCustomerNum();
            break;
         case 8:
            System.out.println("종료");
            System.exit(0);
         }
         System.out.println();      // 줄바꿈
      }
   }
}