package customer;

public class CustomerVO {
   private String name;
   private String customerNum;
   private String contactNum;
   
   @Override
   public String toString() {
      if (customerNum == null || name == null || contactNum == null) return null;
      String str = String.format("%s\t%s\t%s", customerNum, name, contactNum);
      return str;
   }
      
   // getter / setter   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getCustomerNum() {
      return customerNum;
   }
   public void setCustomerNum(String customerNum) {
      this.customerNum = customerNum;
   }
   public String getContactNum() {
      return contactNum;
   }
   public void setContactNum(String contactNum) {
      this.contactNum = contactNum;
   }
}