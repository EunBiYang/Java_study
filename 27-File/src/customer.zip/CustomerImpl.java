package customer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class CustomerImpl implements Customer {

   // 선언
   Scanner sc = new Scanner(System.in);
   List<CustomerVO> list = new ArrayList<CustomerVO>();   
   
   // 입력   
   @Override
   public void input() {
      CustomerVO vo = new CustomerVO();
      System.out.print("고객번호 : ");
      vo.setCustomerNum(sc.next());
      System.out.print("이   름 : ");
      vo.setName(sc.next());
      System.out.print("전화번호 : ");
      vo.setContactNum(sc.next());
      
      list.add(vo);
   }
   
   // 출력
   @Override
   public void print() {
      if (list.size() > 0) {
         printTitle();
         
         for (int i=0; i<list.size(); i++) {
            System.out.println(list.get(i).toString());
         }
      } else {
         System.out.println("등록된 고객정보가 없습니다.");
      }
   }
   
   // 제목 출력
   @Override
   public void printTitle() {
      System.out.println("고객번호\t이름\t전화번호");
   }
   
   // 고객번호(customerNum) 검색
   @Override
   public void searchCustomerNum() {
      System.out.print("검색할 고객번호? ");
      String customerNum = sc.next();
      int flag = -1;
      
      for (int i = 0; i < list.size(); i++) {
         CustomerVO vo = list.get(i);
         if (customerNum.equals(vo.getCustomerNum())) {
            printTitle();
            System.out.println(vo.toString());
            flag = 0;
         }
      }
      if (flag == -1)
         System.out.println(customerNum + " 는 없는 고객번호입니다.");
   }
   
   // 이름(name) 검색
   @Override
   public void searchName() {
      System.out.print("검색할 이름? ");
      String name = sc.next();
      int flag = -1;
      
      for (int i=0; i < list.size(); i++) {
         CustomerVO vo = list.get(i);
         if (name.equals(vo.getName())) {
            printTitle();
            System.out.println(vo.toString());
            flag = 0;
         }
      }
      if (flag == -1)
         System.out.println(name + " 님은 없는 고객명입니다.");
   }
   
   // 전화번호(contactNum) 검색
   @Override
   public void searchContactNum() {
      System.out.print("검색할 전화번호? ");
      String contactNum = sc.next();
      int flag = -1;
      
      for (int i=0; i < list.size(); i++) {
         CustomerVO vo = list.get(i);
         if (contactNum.equals(vo.getContactNum())) {
            printTitle();
            System.out.println(vo.toString());
            flag = 0;
         }
      }
      if (flag == -1)
         System.out.println(contactNum + " 는 없는 전화번호입니다.");
      
   }
   
   // 이름 내림차순 정렬
   @Override
   public void descSortName() {
      // 정렬 기준
      Comparator<CustomerVO> comp1 = new Comparator<CustomerVO>() {

         @Override
         public int compare(CustomerVO o1, CustomerVO o2) {
            return o2.getName().compareTo(o1.getName());

         }   
      };
   
      // 정렬
      Collections.sort(list, comp1);
      print();
   }
   
   // 고객번호 오름차순 정렬
   @Override
   public void ascSortCustomerNum() {
      // 정렬 기준
      Comparator<CustomerVO> comp2 = new Comparator<CustomerVO>() {

         @Override
         public int compare(CustomerVO o1, CustomerVO o2) {
        	 int num1 = Integer.parseInt(o1.getCustomerNum());
        	 int num2 = Integer.parseInt(o2.getCustomerNum());
            return num1 > num2 ? 1 : -1;
         }
      };
      // 정렬(오름차순)
      Collections.sort(list,comp2);
      print();
   }
}
